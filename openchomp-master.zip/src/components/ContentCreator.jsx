import React, { PureComponent } from 'react';
import ReactDOM from 'react-dom';
import uuidv4 from 'uuid/v4';
import loremIpsum from 'lorem-ipsum';
import { TextField, IconButton, Paper, Button, Grid, withStyles } from '@material-ui/core';
import { ModeComment, Delete } from '@material-ui/icons';
// import RGL, { WidthProvider } from "react-grid-layout";
import { DraggableCore } from 'react-draggable';
import './ContentCreator.scss';

// const ReactGridLayout = WidthProvider(RGL);

const styles = (theme) => ({
  child: {
    position: 'absolute',
    // border: '1px #000 solid',
    // borderRadius: 5,
    // padding: theme.spacing.unit * 2,
    cursor: 'pointer',
    width: '100%'
  },
  closeButton: {
    position: 'absolute',
    right: 2,
    top: 2
  },
  draggable: {
    // position: 'relative',
    // background: 'red',
    // width: 100,
    // height: 100
  },
  field: {
    margin: '20px 0'
  },
  paper: {
    // minHeight: 200,
    // padding: theme.spacing.unit,
    // margin: theme.spacing.unit,
    // overflow: 'hidden'
    height: 'auto'
  },
  text: {
    // width: '98%',
    // height: '100%',
    // overflow: 'hidden'

    margin: theme.spacing.unit
  },
  container: {
    // position: 'fixed',
    // top: 0,
    // right: 200
    background: '#ccc',
    minHeight: 400,
    padding: theme.spacing.unit
  },
  innerContainer: {
    position: 'relative',
  },
  left: {
    background: '#ddd'
  }
});

const cl = (...classArr) => {
  return classArr.join(' ');
};

class ContentCreator extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      controls: [
        { id: 0, left: 0, top: 0, zIndex: 1 },
        { id: 1, left: 0, top: 75, zIndex: 1 }
      ]
      // dragging: { top: 0, left: null }
    };
  }

  onStart = (id, e, { node, deltaX, deltaY }) => {
    // console.log(id)
    const { offsetParent } = node;
    const parentRect = offsetParent.getBoundingClientRect();
    const clientRect = node.getBoundingClientRect();
    const newPosition = { top: 0, left: 0 };
    newPosition.left = clientRect.left - parentRect.left + offsetParent.scrollLeft;
    newPosition.top = clientRect.top - parentRect.top + offsetParent.scrollTop;
    const controls = [...this.state.controls];
    const control = controls.find(x => x.id === id);
    control.top = newPosition.top;
    control.left = newPosition.left;
    control.zIndex = 99;
    this.setState({ controls });
    // console.log(newPosition);
  }

  onDrag = (id, e, { node, deltaX, deltaY }) => {

    const controls = [...this.state.controls];
    const control = controls.find(x => x.id === id);

    const newPosition = { top: 0, left: 0 };
    newPosition.left = control.left + deltaX;
    newPosition.top = control.top + deltaY;

    control.top = newPosition.top;
    control.left = newPosition.left;
    this.setState({ controls });
    // console.log(newPosition)
    // this.setState({ dragging: newPosition });
    // console.log(e);
  }

  onStop = (id, e, { node, deltaX, deltaY }) => {
    const controls = [...this.state.controls];
    const control = controls.find(x => x.id === id);
    control.zIndex = 1;
    // console.log(control);
    this.setState({ controls });
  }

  // calcPosition = (dragging) => {
  //   console.log(dragging);
  //   return dragging;
  // }

  render() {
    const { classes, children } = this.props;
    const { fields, colCount, layout, newId, dragging, controls } = this.state;

    // const pos = this.calcPosition(dragging);
    // const child = React.Children.only(children);
    // let newChild = React.cloneElement(child, {});

    return (
      <div>
        <Grid container>
          <Grid item xs={8}>
            <div className={cl(classes.container, classes.left)}
            ></div>
          </Grid>
          <Grid item xs={4}>
            <div className={classes.container}>
              <div className={classes.innerContainer}>
                {controls.map(control => (
                  <DraggableCore
                    key={control.id}
                    onStart={this.onStart.bind(this, control.id)}
                    onDrag={this.onDrag.bind(this, control.id)}
                    onStop={this.onStop.bind(this, control.id)}
                  >
                    <Paper className={classes.child} style={control}>
                      <TextField className={classes.text} disabled value="Text Block" />
                    </Paper>

                  </DraggableCore>
                ))}
              </div>
            </div>


            {/* <DraggableCore
              onStart={this.onStart}
              onDrag={this.onDrag}
            >
              <Paper className={classes.child} style={dragging}>
                <TextField disabled value="Text Block" />
              </Paper>

            </DraggableCore>
            <DraggableCore
              onStart={this.onStart}
              onDrag={this.onDrag}
            >
              <Paper className={classes.child} style={dragging}>
                <TextField disabled value="Text Block" />
              </Paper>

            </DraggableCore> */}
          </Grid>
        </Grid>
      </div>
    );
  }
}

export default withStyles(styles)(ContentCreator);